#include "graph_runtime.h"
volatile uint64_t tohost __attribute__((section(".tohost"),aligned(64)))=0;
volatile uint64_t fromhost __attribute__((section(".tohost"),aligned(64)))=0;
extern const unsigned char command_blob[],payload_blob[];
static uint64_t completion[38];
static volatile mlx_graph_result result;
static const volatile mlx_graph_asset assets[]={{.source=(uintptr_t)(payload_blob+0),.destination=UINT64_C(4295032832),.bytes=64},{.source=(uintptr_t)(payload_blob+64),.destination=UINT64_C(4295032896),.bytes=8},{.source=(uintptr_t)(payload_blob+72),.destination=UINT64_C(4295032960),.bytes=128}};
static const volatile mlx_graph_task tasks[]={{.kind=2,.source_ordinal=0,.source_id=0,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+0)},{.kind=2,.source_ordinal=1,.source_id=1,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+4288)},{.kind=2,.source_ordinal=2,.source_id=2,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+8576)},{.kind=2,.source_ordinal=3,.source_id=3,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+12864)},{.kind=2,.source_ordinal=4,.source_id=4,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+17152)},{.kind=2,.source_ordinal=5,.source_id=5,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+21440)},{.kind=2,.source_ordinal=6,.source_id=6,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+25728)},{.kind=2,.source_ordinal=7,.source_id=7,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+30016)},{.kind=2,.source_ordinal=8,.source_id=8,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+34304)},{.kind=2,.source_ordinal=9,.source_id=9,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+38592)},{.kind=2,.source_ordinal=10,.source_id=10,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+42880)},{.kind=2,.source_ordinal=11,.source_id=11,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+47168)},{.kind=2,.source_ordinal=12,.source_id=12,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+51456)},{.kind=2,.source_ordinal=13,.source_id=13,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+55744)},{.kind=2,.source_ordinal=14,.source_id=14,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+60032)},{.kind=2,.source_ordinal=15,.source_id=15,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+64320)},{.kind=2,.source_ordinal=16,.source_id=16,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+68608)},{.kind=2,.source_ordinal=17,.source_id=17,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+72896)},{.kind=2,.source_ordinal=18,.source_id=18,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+77184)},{.kind=2,.source_ordinal=19,.source_id=19,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+81472)},{.kind=2,.source_ordinal=20,.source_id=20,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+85760)},{.kind=2,.source_ordinal=21,.source_id=21,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+90048)},{.kind=2,.source_ordinal=22,.source_id=22,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+94336)},{.kind=2,.source_ordinal=23,.source_id=23,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+98624)},{.kind=2,.source_ordinal=24,.source_id=24,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+102912)},{.kind=2,.source_ordinal=25,.source_id=25,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+107200)},{.kind=2,.source_ordinal=26,.source_id=26,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+111488)},{.kind=2,.source_ordinal=27,.source_id=27,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+115776)},{.kind=2,.source_ordinal=28,.source_id=28,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+120064)},{.kind=2,.source_ordinal=29,.source_id=29,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+124352)},{.kind=2,.source_ordinal=30,.source_id=30,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+128640)},{.kind=2,.source_ordinal=31,.source_id=31,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+132928)},{.kind=2,.source_ordinal=32,.source_id=32,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+137216)},{.kind=0,.source_ordinal=33,.source_id=33,.batch_index=0,.batch_count=1,.bytes=0,.command=0},{.kind=0,.source_ordinal=34,.source_id=34,.batch_index=0,.batch_count=1,.bytes=0,.command=0},{.kind=2,.source_ordinal=35,.source_id=35,.batch_index=0,.batch_count=1,.bytes=15872,.command=(uintptr_t)(command_blob+141504)},{.kind=0,.source_ordinal=36,.source_id=36,.batch_index=0,.batch_count=1,.bytes=0,.command=0},{.kind=2,.source_ordinal=37,.source_id=37,.batch_index=0,.batch_count=1,.bytes=15872,.command=(uintptr_t)(command_blob+157376)}};
static const uint64_t dependencies_0[]={0};
static const uint64_t dependencies_1[]={0};
static const uint64_t dependencies_2[]={1};
static const uint64_t dependencies_3[]={2};
static const uint64_t dependencies_4[]={3};
static const uint64_t dependencies_5[]={4};
static const uint64_t dependencies_6[]={5};
static const uint64_t dependencies_7[]={6};
static const uint64_t dependencies_8[]={6,7};
static const uint64_t dependencies_9[]={8};
static const uint64_t dependencies_10[]={6,9};
static const uint64_t dependencies_11[]={8};
static const uint64_t dependencies_12[]={11};
static const uint64_t dependencies_13[]={12};
static const uint64_t dependencies_14[]={13};
static const uint64_t dependencies_15[]={14};
static const uint64_t dependencies_16[]={13,15};
static const uint64_t dependencies_17[]={16};
static const uint64_t dependencies_18[]={13,17};
static const uint64_t dependencies_19[]={18};
static const uint64_t dependencies_20[]={13,19};
static const uint64_t dependencies_21[]={20};
static const uint64_t dependencies_22[]={13,21};
static const uint64_t dependencies_23[]={6};
static const uint64_t dependencies_24[]={23};
static const uint64_t dependencies_25[]={24};
static const uint64_t dependencies_26[]={22,25};
static const uint64_t dependencies_27[]={26};
static const uint64_t dependencies_28[]={27};
static const uint64_t dependencies_29[]={10,28};
static const uint64_t dependencies_30[]={29};
static const uint64_t dependencies_31[]={1};
static const uint64_t dependencies_32[]={30,31};
static const uint64_t dependencies_33[]={32};
static const uint64_t dependencies_34[]={33};
static const uint64_t dependencies_35[]={34};
static const uint64_t dependencies_36[]={33};
static const uint64_t dependencies_37[]={36};
static const volatile mlx_graph_source source_table[]={{.source_id=0,.dependencies=(uintptr_t)dependencies_0,.dependency_count=0,.reserved=1},{.source_id=1,.dependencies=(uintptr_t)dependencies_1,.dependency_count=1,.reserved=2},{.source_id=2,.dependencies=(uintptr_t)dependencies_2,.dependency_count=1,.reserved=3},{.source_id=3,.dependencies=(uintptr_t)dependencies_3,.dependency_count=1,.reserved=3},{.source_id=4,.dependencies=(uintptr_t)dependencies_4,.dependency_count=1,.reserved=3},{.source_id=5,.dependencies=(uintptr_t)dependencies_5,.dependency_count=1,.reserved=3},{.source_id=6,.dependencies=(uintptr_t)dependencies_6,.dependency_count=1,.reserved=3},{.source_id=7,.dependencies=(uintptr_t)dependencies_7,.dependency_count=1,.reserved=3},{.source_id=8,.dependencies=(uintptr_t)dependencies_8,.dependency_count=2,.reserved=3},{.source_id=9,.dependencies=(uintptr_t)dependencies_9,.dependency_count=1,.reserved=3},{.source_id=10,.dependencies=(uintptr_t)dependencies_10,.dependency_count=2,.reserved=3},{.source_id=11,.dependencies=(uintptr_t)dependencies_11,.dependency_count=1,.reserved=3},{.source_id=12,.dependencies=(uintptr_t)dependencies_12,.dependency_count=1,.reserved=3},{.source_id=13,.dependencies=(uintptr_t)dependencies_13,.dependency_count=1,.reserved=3},{.source_id=14,.dependencies=(uintptr_t)dependencies_14,.dependency_count=1,.reserved=3},{.source_id=15,.dependencies=(uintptr_t)dependencies_15,.dependency_count=1,.reserved=3},{.source_id=16,.dependencies=(uintptr_t)dependencies_16,.dependency_count=2,.reserved=3},{.source_id=17,.dependencies=(uintptr_t)dependencies_17,.dependency_count=1,.reserved=3},{.source_id=18,.dependencies=(uintptr_t)dependencies_18,.dependency_count=2,.reserved=3},{.source_id=19,.dependencies=(uintptr_t)dependencies_19,.dependency_count=1,.reserved=3},{.source_id=20,.dependencies=(uintptr_t)dependencies_20,.dependency_count=2,.reserved=3},{.source_id=21,.dependencies=(uintptr_t)dependencies_21,.dependency_count=1,.reserved=3},{.source_id=22,.dependencies=(uintptr_t)dependencies_22,.dependency_count=2,.reserved=3},{.source_id=23,.dependencies=(uintptr_t)dependencies_23,.dependency_count=1,.reserved=3},{.source_id=24,.dependencies=(uintptr_t)dependencies_24,.dependency_count=1,.reserved=3},{.source_id=25,.dependencies=(uintptr_t)dependencies_25,.dependency_count=1,.reserved=3},{.source_id=26,.dependencies=(uintptr_t)dependencies_26,.dependency_count=2,.reserved=3},{.source_id=27,.dependencies=(uintptr_t)dependencies_27,.dependency_count=1,.reserved=3},{.source_id=28,.dependencies=(uintptr_t)dependencies_28,.dependency_count=1,.reserved=3},{.source_id=29,.dependencies=(uintptr_t)dependencies_29,.dependency_count=2,.reserved=3},{.source_id=30,.dependencies=(uintptr_t)dependencies_30,.dependency_count=1,.reserved=3},{.source_id=31,.dependencies=(uintptr_t)dependencies_31,.dependency_count=1,.reserved=3},{.source_id=32,.dependencies=(uintptr_t)dependencies_32,.dependency_count=2,.reserved=3},{.source_id=33,.dependencies=(uintptr_t)dependencies_33,.dependency_count=1,.reserved=4},{.source_id=34,.dependencies=(uintptr_t)dependencies_34,.dependency_count=1,.reserved=5},{.source_id=35,.dependencies=(uintptr_t)dependencies_35,.dependency_count=1,.reserved=6},{.source_id=36,.dependencies=(uintptr_t)dependencies_36,.dependency_count=1,.reserved=7},{.source_id=37,.dependencies=(uintptr_t)dependencies_37,.dependency_count=1,.reserved=8}};
static volatile mlx_graph_source_group source_groups[]={{.source_id=0,.stage_begin=0,.stage_count=1},{.source_id=1,.stage_begin=1,.stage_count=1},{.source_id=2,.stage_begin=2,.stage_count=31},{.source_id=3,.stage_begin=33,.stage_count=1},{.source_id=4,.stage_begin=34,.stage_count=1},{.source_id=5,.stage_begin=35,.stage_count=1},{.source_id=6,.stage_begin=36,.stage_count=1},{.source_id=7,.stage_begin=37,.stage_count=1}};
static const volatile mlx_graph_program program={.magic=MLX_GRAPH_MAGIC,.version=3,.source_count=38,.task_count=38,.asset_count=3,.assets=(uintptr_t)assets,.tasks=(uintptr_t)tasks,.device_base=UINT64_C(4294967296),.device_bytes=UINT64_C(1048576),.scratch_offset=4096,.scratch_bytes=16384,.poll_limit=UINT64_C(1000000000000),.completion=(uintptr_t)completion,.reserved={(uintptr_t)source_table,8,(uintptr_t)source_groups}};
#include "qa_output.h"
static int qa_same(const void *a,const unsigned char *b,uint64_t n){const unsigned char *p=a;for(uint64_t i=0;i<n;++i)if(p[i]!=b[i])return 0;return 1;}
static const volatile mlx_host_tensor qa_views_0[]={{UINT64_C(4295033088),UINT64_C(32),UINT64_C(0),UINT64_C(2),UINT64_C(1),UINT64_C(1),{1,8,0,0,0,0,0,0},{8,1,0,0,0,0,0,0}},{UINT64_C(4295033152),UINT64_C(32),UINT64_C(0),UINT64_C(2),UINT64_C(1),UINT64_C(1),{1,8,0,0,0,0,0,0},{8,1,0,0,0,0,0,0}},{UINT64_C(4295032896),UINT64_C(8),UINT64_C(0),UINT64_C(1),UINT64_C(3),UINT64_C(1),{8,0,0,0,0,0,0,0},{1,0,0,0,0,0,0,0}},{UINT64_C(4295032960),UINT64_C(128),UINT64_C(0),UINT64_C(2),UINT64_C(2),UINT64_C(1),{8,2,0,0,0,0,0,0},{2,1,0,0,0,0,0,0}}};
static float qa_start_0[8],qa_end_0[8];
static uint8_t qa_mask_0[8];
static int64_t qa_offsets_0[16];
static mlx_qa_span qa_span_0;
static const unsigned char qa_expected_start_0[]={204,159,107,62,0,0,136,65,187,178,190,64,84,64,116,181,179,205,232,63,235,163,38,190,3,96,151,63,210,221,110,63};
static const unsigned char qa_expected_end_0[]={6,215,253,188,0,0,136,65,115,219,173,64,163,146,83,62,92,27,145,63,176,170,15,62,22,157,214,189,94,236,86,64};
static const unsigned char qa_expected_mask_0[]={0,1,1,1,1,1,1,0};
static const unsigned char qa_expected_offsets_0[]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,18,0,0,0,0,0,0,0,18,0,0,0,0,0,0,0,24,0,0,0,0,0,0,0,24,0,0,0,0,0,0,0,30,0,0,0,0,0,0,0,30,0,0,0,0,0,0,0,36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const uint64_t qa_score_bits_0=UINT64_C(4629981891913580544);
static uint64_t cpu_cycle(void){uint64_t n;__asm__ volatile("rdcycle %0":"=r"(n)::"memory");return n;}
struct check {uint64_t base,offset,rank,width,count,shape[8],stride[8];const unsigned char *expected;};
static const volatile struct check checks[]={{0}};
static const uint64_t source_ids[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38};
int main(void){
uint64_t qa_begin=cpu_cycle();
if(mlx_graph_execute(&program,&result))return 10;
uint64_t qa_graph_end=cpu_cycle();
if(mlx_host_qa_capture(qa_views_0,8,qa_start_0,qa_end_0,qa_mask_0,qa_offsets_0,&qa_span_0))return 20;
uint64_t qa_post_end=cpu_cycle();
if(result.status||result.completed_sources!=38||result.host_calls!=0||result.view_elisions!=3)return 11;
if(result.device_calls!=35||result.asset_bytes!=200)return 14;
for(unsigned i=0;i<38;++i)if(completion[i]!=source_ids[i])return 12;
if(result.completed_source_groups!=8)return 15;
for(unsigned i=0;i<8;++i)if(source_groups[i].completed_stages!=source_groups[i].stage_count)return 16;
for(unsigned row=0;row<sizeof(checks)/sizeof(checks[0]);++row){
const volatile struct check *c=&checks[row];for(uint64_t flat=0;flat<c->count;++flat){uint64_t index=flat,at=c->offset;for(unsigned d=(unsigned)c->rank;d-->0;){at+=(index%c->shape[d])*c->stride[d];index/=c->shape[d];}const volatile unsigned char *actual=(const volatile unsigned char *)(uintptr_t)(c->base+at*c->width);for(unsigned b=0;b<c->width;++b)if(actual[b]!=c->expected[flat*c->width+b])return 13;}
}
if(!qa_same(qa_start_0,qa_expected_start_0,32))return 21;
if(!qa_same(qa_end_0,qa_expected_end_0,32))return 21;
if(!qa_same(qa_mask_0,qa_expected_mask_0,8))return 21;
if(!qa_same(qa_offsets_0,qa_expected_offsets_0,128))return 21;
if(qa_span_0.start!=1||qa_span_0.end!=1||qa_offsets_0[2*qa_span_0.start]!=0||qa_offsets_0[2*qa_span_0.end+1]!=6)return 22;
if(!qa_same(&qa_span_0.score,(const unsigned char *)&qa_score_bits_0,8))return 23;
mlx_host_qa_emit(0,8,qa_start_0,qa_end_0,qa_offsets_0,&qa_span_0);
mlx_host_qa_timing(qa_begin,qa_graph_end,qa_post_end);
return 0;
}
