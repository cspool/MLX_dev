#include "graph_runtime.h"
volatile uint64_t tohost __attribute__((section(".tohost"),aligned(64)))=0;
volatile uint64_t fromhost __attribute__((section(".tohost"),aligned(64)))=0;
extern const unsigned char command_blob[],payload_blob[];
static uint64_t completion[7];
static volatile mlx_graph_result result;
static const volatile mlx_graph_asset assets[]={{.source=(uintptr_t)(payload_blob+0),.destination=UINT64_C(4295032832),.bytes=64},{.source=(uintptr_t)(payload_blob+64),.destination=UINT64_C(4295032896),.bytes=8},{.source=(uintptr_t)(payload_blob+72),.destination=UINT64_C(4295032960),.bytes=128}};
static const volatile mlx_graph_task tasks[]={{.kind=2,.source_ordinal=0,.source_id=0,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+0)},{.kind=2,.source_ordinal=1,.source_id=1,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+4288)},{.kind=0,.source_ordinal=2,.source_id=2,.batch_index=0,.batch_count=1,.bytes=0,.command=0},{.kind=0,.source_ordinal=3,.source_id=3,.batch_index=0,.batch_count=1,.bytes=0,.command=0},{.kind=2,.source_ordinal=4,.source_id=4,.batch_index=0,.batch_count=1,.bytes=15872,.command=(uintptr_t)(command_blob+8576)},{.kind=0,.source_ordinal=5,.source_id=5,.batch_index=0,.batch_count=1,.bytes=0,.command=0},{.kind=2,.source_ordinal=6,.source_id=6,.batch_index=0,.batch_count=1,.bytes=15872,.command=(uintptr_t)(command_blob+24448)}};
static const uint64_t dependencies_0[]={0};
static const uint64_t dependencies_1[]={0};
static const uint64_t dependencies_2[]={1};
static const uint64_t dependencies_3[]={2};
static const uint64_t dependencies_4[]={3};
static const uint64_t dependencies_5[]={2};
static const uint64_t dependencies_6[]={5};
static const volatile mlx_graph_source source_table[]={{.source_id=0,.dependencies=(uintptr_t)dependencies_0,.dependency_count=0,.reserved=1},{.source_id=1,.dependencies=(uintptr_t)dependencies_1,.dependency_count=1,.reserved=2},{.source_id=2,.dependencies=(uintptr_t)dependencies_2,.dependency_count=1,.reserved=3},{.source_id=3,.dependencies=(uintptr_t)dependencies_3,.dependency_count=1,.reserved=4},{.source_id=4,.dependencies=(uintptr_t)dependencies_4,.dependency_count=1,.reserved=5},{.source_id=5,.dependencies=(uintptr_t)dependencies_5,.dependency_count=1,.reserved=6},{.source_id=6,.dependencies=(uintptr_t)dependencies_6,.dependency_count=1,.reserved=7}};
static volatile mlx_graph_source_group source_groups[]={{.source_id=0,.stage_begin=0,.stage_count=1},{.source_id=1,.stage_begin=1,.stage_count=1},{.source_id=2,.stage_begin=2,.stage_count=1},{.source_id=3,.stage_begin=3,.stage_count=1},{.source_id=4,.stage_begin=4,.stage_count=1},{.source_id=5,.stage_begin=5,.stage_count=1},{.source_id=6,.stage_begin=6,.stage_count=1}};
static const volatile mlx_graph_program program={.magic=MLX_GRAPH_MAGIC,.version=3,.source_count=7,.task_count=7,.asset_count=3,.assets=(uintptr_t)assets,.tasks=(uintptr_t)tasks,.device_base=UINT64_C(4294967296),.device_bytes=UINT64_C(1048576),.scratch_offset=4096,.scratch_bytes=16384,.poll_limit=UINT64_C(1000000000000),.completion=(uintptr_t)completion,.reserved={(uintptr_t)source_table,7,(uintptr_t)source_groups}};
#include "qa_output.h"
static int qa_same(const void *a,const unsigned char *b,uint64_t n){const unsigned char *p=a;for(uint64_t i=0;i<n;++i)if(p[i]!=b[i])return 0;return 1;}
static const volatile mlx_host_tensor qa_views_0[]={{UINT64_C(4295033088),UINT64_C(32),UINT64_C(0),UINT64_C(2),UINT64_C(1),UINT64_C(1),{1,8,0,0,0,0,0,0},{8,1,0,0,0,0,0,0}},{UINT64_C(4295033152),UINT64_C(32),UINT64_C(0),UINT64_C(2),UINT64_C(1),UINT64_C(1),{1,8,0,0,0,0,0,0},{8,1,0,0,0,0,0,0}},{UINT64_C(4295032896),UINT64_C(8),UINT64_C(0),UINT64_C(1),UINT64_C(3),UINT64_C(1),{8,0,0,0,0,0,0,0},{1,0,0,0,0,0,0,0}},{UINT64_C(4295032960),UINT64_C(128),UINT64_C(0),UINT64_C(2),UINT64_C(2),UINT64_C(1),{8,2,0,0,0,0,0,0},{2,1,0,0,0,0,0,0}}};
static float qa_start_0[8],qa_end_0[8];
static uint8_t qa_mask_0[8];
static int64_t qa_offsets_0[16];
static mlx_qa_span qa_span_0;
static const unsigned char qa_expected_start_0[]={98,252,183,62,0,0,136,65,187,178,190,64,141,213,162,192,251,22,240,63,14,90,114,191,130,92,167,63,232,190,138,63};
static const unsigned char qa_expected_end_0[]={104,103,12,192,0,0,136,65,115,219,173,64,64,62,168,62,80,202,161,63,232,22,114,62,12,107,187,191,221,1,87,64};
static const unsigned char qa_expected_mask_0[]={0,1,1,1,1,1,1,0};
static const unsigned char qa_expected_offsets_0[]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,18,0,0,0,0,0,0,0,18,0,0,0,0,0,0,0,24,0,0,0,0,0,0,0,24,0,0,0,0,0,0,0,30,0,0,0,0,0,0,0,30,0,0,0,0,0,0,0,36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const uint64_t qa_score_bits_0=UINT64_C(4629981891913580544);
static uint64_t cpu_cycle(void){uint64_t n;__asm__ volatile("rdcycle %0":"=r"(n)::"memory");return n;}
struct check {uint64_t base,offset,rank,width,count,shape[8],stride[8];const unsigned char *expected;};
static const volatile struct check checks[]={{0}};
static const uint64_t source_ids[]={1,2,3,4,5,6,7};
int main(void){
uint64_t qa_begin=cpu_cycle();
if(mlx_graph_execute(&program,&result))return 10;
uint64_t qa_graph_end=cpu_cycle();
if(mlx_host_qa_capture(qa_views_0,8,qa_start_0,qa_end_0,qa_mask_0,qa_offsets_0,&qa_span_0))return 20;
uint64_t qa_post_end=cpu_cycle();
if(result.status||result.completed_sources!=7||result.host_calls!=0||result.view_elisions!=3)return 11;
if(result.device_calls!=4||result.asset_bytes!=200)return 14;
for(unsigned i=0;i<7;++i)if(completion[i]!=source_ids[i])return 12;
if(result.completed_source_groups!=7)return 15;
for(unsigned i=0;i<7;++i)if(source_groups[i].completed_stages!=source_groups[i].stage_count)return 16;
for(unsigned row=0;row<sizeof(checks)/sizeof(checks[0]);++row){
const volatile struct check *c=&checks[row];for(uint64_t flat=0;flat<c->count;++flat){uint64_t index=flat,at=c->offset;for(unsigned d=(unsigned)c->rank;d-->0;){at+=(index%c->shape[d])*c->stride[d];index/=c->shape[d];}const volatile unsigned char *actual=(const volatile unsigned char *)(uintptr_t)(c->base+at*c->width);for(unsigned b=0;b<c->width;++b)if(actual[b]!=c->expected[flat*c->width+b])return 13;}
}
if(!qa_same(qa_start_0,qa_expected_start_0,32))return 21;
if(!qa_same(qa_end_0,qa_expected_end_0,32))return 21;
if(!qa_same(qa_mask_0,qa_expected_mask_0,8))return 21;
if(!qa_same(qa_offsets_0,qa_expected_offsets_0,128))return 21;
if(qa_span_0.start!=1||qa_span_0.end!=1||qa_offsets_0[2*qa_span_0.start]!=0||qa_offsets_0[2*qa_span_0.end+1]!=6)return 22;
if(!qa_same(&qa_span_0.score,(const unsigned char *)&qa_score_bits_0,8))return 23;
mlx_host_qa_emit(0,8,qa_start_0,qa_end_0,qa_offsets_0,&qa_span_0);
mlx_host_qa_timing(qa_begin,qa_graph_end,qa_post_end);
return 0;
}
