#include "graph_runtime.h"
volatile uint64_t tohost __attribute__((section(".tohost"),aligned(64)))=0;
volatile uint64_t fromhost __attribute__((section(".tohost"),aligned(64)))=0;
extern const unsigned char command_blob[],payload_blob[];
static uint64_t completion[8];
static volatile mlx_graph_result result;
static const volatile mlx_graph_asset assets[]={{.source=(uintptr_t)(payload_blob+0),.destination=UINT64_C(4295032832),.bytes=8},{.source=(uintptr_t)(payload_blob+8),.destination=UINT64_C(4295032896),.bytes=3},{.source=(uintptr_t)(payload_blob+16),.destination=UINT64_C(4295032960),.bytes=4},{.source=(uintptr_t)(payload_blob+24),.destination=UINT64_C(4295033024),.bytes=36}};
static const volatile mlx_graph_task tasks[]={{.kind=1,.source_ordinal=0,.source_id=0,.batch_index=0,.batch_count=1,.bytes=640,.command=(uintptr_t)(command_blob+0)},{.kind=1,.source_ordinal=1,.source_id=1,.batch_index=0,.batch_count=1,.bytes=640,.command=(uintptr_t)(command_blob+640)},{.kind=1,.source_ordinal=2,.source_id=2,.batch_index=0,.batch_count=1,.bytes=640,.command=(uintptr_t)(command_blob+1280)},{.kind=2,.source_ordinal=3,.source_id=3,.batch_index=0,.batch_count=1,.bytes=15936,.command=(uintptr_t)(command_blob+1920)},{.kind=0,.source_ordinal=4,.source_id=4,.batch_index=0,.batch_count=1,.bytes=0,.command=0},{.kind=2,.source_ordinal=5,.source_id=5,.batch_index=0,.batch_count=1,.bytes=15936,.command=(uintptr_t)(command_blob+17856)},{.kind=2,.source_ordinal=6,.source_id=6,.batch_index=0,.batch_count=1,.bytes=4288,.command=(uintptr_t)(command_blob+33792)},{.kind=1,.source_ordinal=7,.source_id=7,.batch_index=0,.batch_count=1,.bytes=640,.command=(uintptr_t)(command_blob+38080)}};
static const volatile mlx_graph_program program={.magic=MLX_GRAPH_MAGIC,.version=1,.source_count=8,.task_count=8,.asset_count=4,.assets=(uintptr_t)assets,.tasks=(uintptr_t)tasks,.device_base=UINT64_C(4294967296),.device_bytes=UINT64_C(1048576),.scratch_offset=4096,.scratch_bytes=16384,.poll_limit=UINT64_C(1000000000000),.completion=(uintptr_t)completion};
static const unsigned char expected_0[]={0,0,0,64,0,0,168,65,0,0,0,65};
static const unsigned char expected_1[]={1,0,0,0,0,0,0,0};
struct check {uint64_t base,offset,rank,width,count,shape[8],stride[8];const unsigned char *expected;};
static const volatile struct check checks[]={{.base=UINT64_C(4295033408),.offset=0,.rank=2,.width=4,.count=3,.shape={1,3},.stride={3,1},.expected=expected_0},{.base=UINT64_C(4295033472),.offset=0,.rank=1,.width=8,.count=1,.shape={1},.stride={1},.expected=expected_1}};
static const uint64_t source_ids[]={1,2,3,4,5,6,7,8};
int main(void){
if(mlx_graph_execute(&program,&result))return 10;
if(result.status||result.completed_sources!=8||result.host_calls!=4||result.view_elisions!=1)return 11;
if(result.device_calls!=3||result.asset_bytes!=51)return 14;
for(unsigned i=0;i<8;++i)if(completion[i]!=source_ids[i])return 12;
for(unsigned row=0;row<sizeof(checks)/sizeof(checks[0]);++row){
const volatile struct check *c=&checks[row];for(uint64_t flat=0;flat<c->count;++flat){uint64_t index=flat,at=c->offset;for(unsigned d=(unsigned)c->rank;d-->0;){at+=(index%c->shape[d])*c->stride[d];index/=c->shape[d];}const volatile unsigned char *actual=(const volatile unsigned char *)(uintptr_t)(c->base+at*c->width);for(unsigned b=0;b<c->width;++b)if(actual[b]!=c->expected[flat*c->width+b])return 13;}
}
return 0;
}
